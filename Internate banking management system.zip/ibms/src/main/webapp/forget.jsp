<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Forget Password</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 35px;
        border-radius: 12px;
        border: 2px solid #0d6efd;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 320px;
        text-align: center;
    }

    h2 {
        margin-bottom: 20px;
        color: #333;
    }

    input {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1.5px solid #ccc;
        border-radius: 6px;
        outline: none;
        transition: 0.3s;
    }

    input:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 6px rgba(13,110,253,0.5);
    }

    input[type="submit"] {
        background-color: #0d6efd;
        color: white;
        border: none;
        cursor: pointer;
        font-weight: bold;
        transition: 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #0b5ed7;
    }
</style>

</head>
<body>

<div class="container">

    <h2>Reset Password</h2>

    <form action="forget" method="post">
        <input type="email" name="email" placeholder="Enter Email" required>
        
        <input type="password" name="new password" placeholder="Enter New Password" required>
        
        <input type="submit" value="Reset">
    </form>

</div>

</body>
</html>