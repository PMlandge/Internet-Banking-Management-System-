<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<%@ page isELIgnored="false" %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 35px;
        border-radius: 12px;
        border: 2px solid #0d6efd;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 350px;
        text-align: center;
    }

    h2 {
        color: #333;
        margin-bottom: 25px;
    }

    .menu a {
        display: block;
        padding: 12px;
        margin: 10px 0;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        transition: 0.3s;
        font-weight: bold;
    }

    .menu a:hover {
        background-color: #0b5ed7;
    }

    .logout {
        background-color: #dc3545 !important;
    }

    .logout:hover {
        background-color: #bb2d3b !important;
    }
</style>

</head>
<body>

<div class="container">

    <h2>Welcome, ${email}</h2>

    <div class="menu">
        <a href="balance">Check Balance</a>
        <a href="sendmoney.jsp">Send Money</a>
        <a href="history">View Statement</a>
        <a href="profile">View Profile</a> 
        <a href="delete.jsp">Delete Account</a> 
             
        <a href="logout" class="logout">Logout</a>
    </div>

</div>

</body>
</html>