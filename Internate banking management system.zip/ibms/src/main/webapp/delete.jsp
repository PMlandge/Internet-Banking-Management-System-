<%@ page isELIgnored="false" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Delete Account</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 35px;
        border-radius: 12px;
        border: 2px solid red;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 350px;
        text-align: center;
    }

    h2 {
        color: red;
        margin-bottom: 20px;
    }

    p {
        font-size: 16px;
        margin-bottom: 20px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        margin: 5px;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
    }

    .delete {
        background-color: red;
        color: white;
    }

    .cancel {
        background-color: #0d6efd;
        color: white;
    }

    .delete:hover {
        background-color: darkred;
    }

    .cancel:hover {
        background-color: #0b5ed7;
    }
</style>

</head>
<body>

<div class="container">

<h2>Delete Account</h2>

<p>Are you sure you want to delete your account?</p>

<a href="delete" class="btn delete">Yes, Delete</a>
<a href="dashboard.jsp" class="btn cancel">Cancel</a>

</div>

</body>
</html>