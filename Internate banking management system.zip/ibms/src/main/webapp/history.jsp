<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<%@ page import="java.util.* , com.jsp.ibms.entity.Users , com.jsp.ibms.entity.BankTransaction " %>
    
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Transaction History</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 30px;
        border-radius: 12px;
        border: 2px solid #0d6efd;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 600px;
        text-align: center;
    }

    h2 {
        margin-bottom: 20px;
        color: #333;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 15px;
    }

    th {
        background-color: #0d6efd;
        color: white;
        padding: 10px;
    }

    td {
        padding: 10px;
        border-bottom: 1px solid #ddd;
        text-align: center;
    }

    tr:hover {
        background-color: #f2f2f2;
    }

    .credit {
        color: green;
        font-weight: bold;
    }

    .debit {
        color: red;
        font-weight: bold;
    }

    a {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        transition: 0.3s;
    }

    a:hover {
        background-color: #0b5ed7;
    }
</style>

</head>
<body>

<div class="container">

    <%
        Users user = (Users) session.getAttribute("user");
    %>

    <h2>Transaction History</h2>
    
    <table>
        <tr>
            <th>Type</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
        
        <%
            List<BankTransaction> list = (List<BankTransaction>) request.getAttribute("txList");
        
            for(BankTransaction btx : list){
                String type =  btx.getSenderId() == user.getId() ? "Debit" : "Credit" ;
        %>
        
        <tr>
            <td class="<%= type.equals("Debit") ? "debit" : "credit" %>">
                <%= type %>
            </td>
            <td>₹ <%= btx.getAmount() %></td>
            <td><%= btx.getTransactionTime() %></td>
        </tr>
        
        <% } %>
    
    </table>
    
    <a href="dashboard.jsp">Back to Dashboard</a>

</div>

</body>
</html>