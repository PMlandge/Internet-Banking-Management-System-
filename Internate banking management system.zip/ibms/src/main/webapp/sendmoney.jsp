<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Send Money</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 35px;
        border-radius: 12px;
        border: 2px solid #0d6efd;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 340px;
        text-align: center;
    }

    h2 {
        margin-bottom: 20px;
        color: #333;
    }

    input {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1.5px solid #ccc;
        border-radius: 6px;
        outline: none;
        transition: 0.3s;
    }

    input:focus {
        border-color: #0d6efd;
        box-shadow: 0 0 6px rgba(13,110,253,0.5);
    }

    input[type="submit"] {
        background-color: #0d6efd;
        color: white;
        border: none;
        cursor: pointer;
        font-weight: bold;
        transition: 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #0b5ed7;
    }

    .message {
        margin-top: 10px;
        color: green;
        font-weight: bold;
    }

    a {
        display: inline-block;
        margin-top: 15px;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        transition: 0.3s;
    }

    a:hover {
        background-color: #0b5ed7;
    }
</style>

</head>
<body>

<div class="container">

    <h2>Send Money</h2>

    <form action="sendmoney" method="post">
       To: <input type="email" name="email" placeholder="Enter Receiver's Email" required>
        
       Amount: <input type="number" name="amount" placeholder="Enter Amount" required>
        
        <input type="submit" value="Send">
    </form>
    
    <p class="message">Message: ${message}</p> 
    
    <a href="dashboard.jsp">Back to Dashboard</a>

</div>

</body>
</html>