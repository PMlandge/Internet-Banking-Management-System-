<%@ page isELIgnored="false" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Profile</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 35px;
        border-radius: 12px;
        border: 2px solid #0d6efd;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 350px;
        text-align: center;
    }

    h2 {
        margin-bottom: 20px;
        color: #333;
    }

    .info {
        font-size: 16px;
        margin: 10px 0;
        color: #444;
    }

    .info span {
        font-weight: bold;
        color: #0d6efd;
    }

    a {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        transition: 0.3s;
    }

    a:hover {
        background-color: #0b5ed7;
    }
</style>

</head>
<body>

<div class="container">

<h2>User Profile</h2>

<div class="info"><span>Name:</span> ${user.name}</div>
<div class="info"><span>Email:</span> ${user.email}</div>
<div class="info"><span>Balance:</span> ₹ ${user.balance}</div>

<a href="dashboard.jsp">Back to Dashboard</a>

</div>

</body>
</html>