<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isELIgnored="false" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Bank Balance</title>

<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background: radial-gradient(circle, rgba(2,0,36,1) 0%, rgba(0,212,255,1) 0%, rgba(9,9,121,1) 100%);
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .container {
        background-color: white;
        padding: 40px;
        border-radius: 12px;
        border: 2px solid #0d6efd;
        box-shadow: 0 10px 25px rgba(0,0,0,0.3);
        width: 350px;
        text-align: center;
    }

    h2 {
        color: #333;
        margin-bottom: 20px;
    }

    .balance {
        font-size: 26px;
        font-weight: bold;
        color: #0d6efd;
        margin: 20px 0;
    }

    a {
        display: inline-block;
        margin-top: 20px;
        padding: 10px 20px;
        background-color: #0d6efd;
        color: white;
        text-decoration: none;
        border-radius: 6px;
        font-weight: bold;
        transition: 0.3s;
    }

    a:hover {
        background-color: #0b5ed7;
    }
</style>

</head>
<body>

<div class="container">

    <h2>Your Bank Balance</h2>
    
    <div class="balance">
        ₹ ${balance}
    </div>

    <a href="dashboard.jsp">Back to Dashboard</a>

</div>

</body>
</html>