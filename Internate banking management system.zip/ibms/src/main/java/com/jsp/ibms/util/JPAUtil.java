package com.jsp.ibms.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {

	
	private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("pg");
	
	private JPAUtil() {
		
	}
	 
	    public static EntityManager getEMF() {
		return emf.createEntityManager();
	}
	    public static void close() {
	        if (emf != null && emf.isOpen()) {
	            emf.close();
	        }
	     }

		
		
}
