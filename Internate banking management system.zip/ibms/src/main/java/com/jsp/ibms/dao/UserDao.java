package com.jsp.ibms.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;

public class UserDao {

	
	public static Users login(String email, String pass) {
		EntityManager em = JPAUtil.getEMF();
		
		try {
			Query query = em.createQuery("FROM Users u WHERE u.email=?1 AND u.password=?2");
			query.setParameter(1, email);
			query.setParameter(2, pass);
			Users user = (Users) query.getSingleResult();
			return (Users) query.getSingleResult();
		} catch (Exception e) {
			return null;
		}
		
	}
}
