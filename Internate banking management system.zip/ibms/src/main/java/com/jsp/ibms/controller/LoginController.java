package com.jsp.ibms.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.ibms.dao.UserDao;
import com.jsp.ibms.entity.Users;

@WebServlet(value = "/login")
public class LoginController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		HttpSession session = req.getSession();
		
		
		Users user = UserDao.login(email, password);
		if (user!=null) {
			System.out.println("Login Successfull");
			session.setAttribute("user", user);
			session.setAttribute("email", user.getEmail());
			session.setAttribute("password", user.getPassword());
			resp.sendRedirect("dashboard.jsp");
		}
		else {
			session.setAttribute("message", "Invalid Credentials");
			resp.sendRedirect("login.jsp");
		}
		System.out.println(user);
	}
}
