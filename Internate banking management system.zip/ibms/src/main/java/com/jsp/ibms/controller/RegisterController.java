package com.jsp.ibms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;


@WebServlet(value = "/register")
public class RegisterController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String password = req.getParameter("password");
		
		
		EntityManager em = JPAUtil.getEMF();
		EntityTransaction et = em.getTransaction();
		
		Users users = new Users();
		users.setName(name);
		users.setEmail(email);
		users.setPassword(password);
		users.setBalance(1000);
		
		et.begin();
		
			em.persist(users);
			
		et.commit();
		
		resp.sendRedirect("login.jsp");
		
	}
}
