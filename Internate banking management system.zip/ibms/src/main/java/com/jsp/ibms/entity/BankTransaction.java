package com.jsp.ibms.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class BankTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int senderId;
	private int receiverId;
	private double amount;
	@CreationTimestamp
	@Column(updatable = false)
	private LocalDate transactionTime;
	
	public BankTransaction() {
		// TODO Auto-generated constructor stub
	}

	public BankTransaction(int id, int senderId, int receiverId, double amount, LocalDate transactionTime) {
		super();
		this.id = id;
		this.senderId = senderId;
		this.receiverId = receiverId;
		this.amount = amount;
		this.transactionTime = transactionTime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSenderId() {
		return senderId;
	}

	public void setSenderId(int senderId) {
		this.senderId = senderId;
	}

	public int getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(int receiverId) {
		this.receiverId = receiverId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public LocalDate getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(LocalDate transactionTime) {
		this.transactionTime = transactionTime;
	}
	
	
	
}
