package com.jsp.ibms.controller;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;

@WebServlet(value = "/balance")
public class BalanceController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		
		EntityManager em = JPAUtil.getEMF();
		EntityTransaction et = em.getTransaction();
		
		try {
			Query query = em.createQuery("FROM Users u WHERE u.email=:email");
			query.setParameter("email", session.getAttribute("email"));
			
			Users user = (Users) query.getSingleResult();
			double balance = user.getBalance();
			
			session.setAttribute("balance", balance);
			resp.sendRedirect("balance.jsp");
		} catch (Exception e) {
			e.printStackTrace();
			
		}	
		
	}
}
