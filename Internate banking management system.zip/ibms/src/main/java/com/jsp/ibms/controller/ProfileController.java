package com.jsp.ibms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.jsp.ibms.entity.Users;

@WebServlet("/profile")
public class ProfileController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        if (session != null && session.getAttribute("user") != null) {

            Users user = (Users) session.getAttribute("user");

            req.setAttribute("user", user);

            req.getRequestDispatcher("profile.jsp").forward(req, resp);

        } else {
            resp.sendRedirect("login.jsp");
        }
    }
}
