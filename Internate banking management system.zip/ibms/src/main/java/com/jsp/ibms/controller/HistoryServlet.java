package com.jsp.ibms.controller;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.ibms.entity.BankTransaction;
import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;

@WebServlet(value = "/history")
public class HistoryServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);
		System.out.println(session);
		System.out.println(session.getAttribute("user"));
		if (session==null || session.getAttribute("user")==null) {
			resp.sendRedirect("login.jsp");
			return;
		}
		
		Users user = (Users) session.getAttribute("user");
		
		EntityManager em = JPAUtil.getEMF();
		List<BankTransaction> list = em.createQuery("FROM BankTransaction WHERE senderId= :id OR " + " receiverId= :id ORDER BY transactionTime DESC", BankTransaction.class)
											.setParameter("id", user.getId())
											.getResultList();
		
		em.close();
		
		req.setAttribute("txList", list);
		req.getRequestDispatcher("history.jsp").forward(req, resp);
	}
}
