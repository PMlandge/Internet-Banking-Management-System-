package com.jsp.ibms.controller;

import java.io.IOException;
import javax.persistence.EntityManager;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;

@WebServlet("/delete")
public class DeleteAccountController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);

        if (session != null && session.getAttribute("user") != null) {

            Users user = (Users) session.getAttribute("user");

            EntityManager em = JPAUtil.getEMF(); 

            em.getTransaction().begin();

            Users u = em.find(Users.class, user.getId());

            if (u != null) 
            {   
                em.remove(u);
            }

            em.getTransaction().commit();

            session.invalidate();

            resp.sendRedirect("register.jsp");

        } else {
            resp.sendRedirect("login.jsp");
        }
    }
}
