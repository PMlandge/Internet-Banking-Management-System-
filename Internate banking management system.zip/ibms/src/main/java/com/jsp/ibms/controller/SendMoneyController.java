package com.jsp.ibms.controller;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jsp.ibms.entity.BankTransaction;
import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;


@WebServlet(value = "/sendmoney")
public class SendMoneyController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session = req.getSession();
		Users senderSession = (Users) session.getAttribute("user");
		
		String email = req.getParameter("email");
		String amount = req.getParameter("amount");
		
		EntityManager em = JPAUtil.getEMF();
		EntityTransaction et = em.getTransaction();
		
		
		boolean verifyEmail = false;
		
		try {
			
			Query query = em.createQuery("FROM Users WHERE email=?1");
			query.setParameter(1, email);
			
			Users toUser = (Users)query.getSingleResult();
			verifyEmail = true;
			System.out.println("Receiver's Email:  " + toUser.getEmail());
			
			
			Query q = em.createQuery("FROM Users WHERE email=?1");
			q.setParameter(1, session.getAttribute("email"));
			
			Users fromUser = (Users) q.getSingleResult();
			System.out.println( "Sender Email:  " + fromUser.getEmail());
			
			BankTransaction btx = new BankTransaction();
			
			double remainedBalance = fromUser.getBalance()-Double.parseDouble(amount);
			if (remainedBalance>50) {
				toUser.setBalance(toUser.getBalance()+Double.parseDouble(amount));
				fromUser.setBalance(remainedBalance);
				
				btx.setSenderId(fromUser.getId());
				btx.setReceiverId(toUser.getId());
				btx.setAmount(Double.parseDouble(amount));
			}
			else {
				session.setAttribute("message", "Insufficient Balance :( ");
				throw new Exception();
			}
			
			
			et.begin();
				em.merge(toUser);
				em.merge(fromUser);
				em.persist(btx);
				
				
			et.commit();
			
			session.setAttribute("message", "Transaction Successfull :)");
			resp.sendRedirect("sendmoney.jsp");
			
		} catch (Exception e) {
			if (!verifyEmail) {
				session.setAttribute("message", "Invalid Receiver's Email :(");
			}
			resp.sendRedirect("sendmoney.jsp");
		}
		finally {
			em.close();
		}
		
	}
}
