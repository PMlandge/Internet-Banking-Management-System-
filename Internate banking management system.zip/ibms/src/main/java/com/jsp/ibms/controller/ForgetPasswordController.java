package com.jsp.ibms.controller;

import java.io.IOException;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jsp.ibms.entity.Users;
import com.jsp.ibms.util.JPAUtil;


@WebServlet(value = "/forget")
public class ForgetPasswordController extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Request came to Forget class");
		
		String email = req.getParameter("email");
		String newPass = req.getParameter("new password");
		
		EntityManager em = JPAUtil.getEMF();
		EntityTransaction et = em.getTransaction();
		
		try {
			Query query = em.createQuery("FROM Users u WHERE u.email=?1");
			query.setParameter(1, email);
			Users user = (Users) query.getSingleResult();
			
			user.setPassword(newPass);
			
			et.begin();
			
				em.merge(user);
			
			et.commit();
			
		} catch (Exception e) 
		{
			System.out.println("Entered email does not exists in DB :(");
			req.setAttribute("error", "Invalid Email");
			
		}
		finally{
			em.close();
			RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
			rd.forward(req, resp);
		}
		 
	}
}
